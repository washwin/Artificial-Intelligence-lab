/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloPlayer.h"
#include "OthelloBoard.h"
#include <cstdlib>
using namespace std;
using namespace Desdemona;

class MyBot : public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
        virtual int AlphaBetaPruning(OthelloBoard &board, Turn turn, int depth, Move move, int Min, int Max);
        virtual int heuristic(OthelloBoard &board, int mode);
    private:
};

MyBot::MyBot(Turn turn) : OthelloPlayer(turn) {}
// parameterized constructor, sends turn as call by value for the parent constructor as well

int MyBot::heuristic(OthelloBoard &board, int mode)
{
    int heuristic_value;
    switch (mode)
    {
    case 0:
    {
        int myValue = 0;
        int oppValue = 0;
        int A[4][2] = {{0,0},{0,7},{7,0},{7,7}};
        int B[8][2] = {{7,5},{5,7},{7,2},{7,2},{5,0},{0,5},{0,2},{2,0}};
        int C[8][2] = {{4,7},{7,4},{4,0},{0,4},{7,3},{3,7},{0,3},{3,0}};
        int D[4][2] = {{2,5},{5,5},{5,2},{2,2}};
        int E[4][2] = {{3,5},{4,5},{4,2},{3,2}};
        int F[4][2] = {{3,3},{3,4},{4,3},{4,4}};
        int G[12][2] = {{2,1},{1,2},{5,6},{6,5},{1,5},{5,1},{6,2},{2,6},{2,3},{2,4},{5,3},{5,4}};
        int H[8][2] = {{3,1},{1,3},{6,4},{4,6},{1,4},{4,1},{6,3},{3,6}};
        int I[4][2] = {{1,1},{1,6},{6,1},{6,6}};
        int J[8][2] = {{1,0},{0,1},{7,1},{1,7},{0,6},{6,0},{6,7},{7,6}};
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(A[i][0],A[i][1]) == this->turn)
                myValue += 1616;
            else if (board.get(A[i][0],A[i][1]) == other(this->turn))
                oppValue += 1616;
        }
        for (int i = 0; i < 8; ++i)
        {
            if (board.get(B[i][0],B[i][1]) == this->turn)
                myValue += 116;
            else if (board.get(B[i][0],B[i][1]) == other(this->turn))
                oppValue += 116;
        }
        for (int i = 0; i < 8; ++i)
        {
            if (board.get(C[i][0],C[i][1]) == this->turn)
                myValue += 53;
            else if (board.get(C[i][0],C[i][1]) == other(this->turn))
                oppValue += 53;
        }
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(D[i][0],D[i][1]) == this->turn)
                myValue += 51;
            else if (board.get(D[i][0],D[i][1]) == other(this->turn))
                oppValue += 51;
        }
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(E[i][0],E[i][1]) == this->turn)
                myValue += 7;
            else if (board.get(E[i][0],E[i][1]) == other(this->turn))
                oppValue += 7;
        }
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(F[i][0],F[i][1]) == this->turn)
                myValue -= 1;
            else if (board.get(F[i][0],F[i][1]) == other(this->turn))
                oppValue -= 1;
        }
        for (int i = 0; i < 12; ++i)
        {
            if (board.get(G[i][0],G[i][1]) == this->turn)
                myValue -= 6;
            else if (board.get(G[i][0],G[i][1]) == other(this->turn))
                oppValue -= 6;
        }
        for (int i = 0; i < 8; ++i)
        {
            if (board.get(H[i][0],H[i][1]) == this->turn)
                myValue -= 23;
            else if (board.get(H[i][0],H[i][1]) == other(this->turn))
                oppValue -= 23;
        }
        for (int i = 0; i < 4; ++i)
        {
            if (board.get(I[i][0],I[i][1]) == this->turn)
                myValue -= 181;
            else if (board.get(I[i][0],I[i][1]) == other(this->turn))
                oppValue -= 181;
        }
        for (int i = 0; i < 8; ++i)
        {
            if (board.get(J[i][0],J[i][1]) == this->turn)
                myValue -= 351;
            else if (board.get(J[i][0],J[i][1]) == other(this->turn))
                oppValue -= 351;
        }
        heuristic_value = myValue - oppValue;
    }
    case 1:
    {
        heuristic_value = board.getValidMoves(this->turn).size() - board.getValidMoves(other(this->turn)).size();
    }
    case 2:
    {
        if (this->turn == RED)
            {
                heuristic_value = board.getRedCount() - board.getBlackCount();
            }
        else
            {
                heuristic_value = board.getBlackCount() - board.getRedCount();
            }
    }
    }
    return heuristic_value;
}

Move MyBot::play(const OthelloBoard &board)
{
    list<Move> moves = board.getValidMoves(turn);
    Move best_move = *moves.begin();
    int depth = 3;
    int best_so_far = -22120212;
        for (Move nextMove : moves)
        {
            OthelloBoard gBoard = OthelloBoard(board);
            int hvalue = AlphaBetaPruning(gBoard, this->turn, depth, nextMove, -22120212, 22120212);
            
            if (hvalue > best_so_far)
            {
                best_move = nextMove;
                best_so_far = hvalue;
            }
            if (hvalue == -22120212)
                return best_move;
        }
    // board.print();
    return best_move;
}

int MyBot::AlphaBetaPruning(OthelloBoard &board, Turn turn, int depth, Move move, int Min, int Max)
{
    OthelloBoard gBoard = OthelloBoard(board);
    gBoard.makeMove(turn, move);
    list<Move> gameTree = gBoard.getValidMoves(other(turn));

    if (depth == 0)
    {
        return heuristic(gBoard, 0);
    }
    int temp;
    for (Move child : gameTree)
    {
        OthelloBoard interBoard = OthelloBoard(board);
        interBoard.makeMove(turn, move);
        temp = child.x + child.y;
        temp++;
    }
    int bestValue;
    if (this->turn == turn)
    {
        bestValue = 22120212;
    }
    else
    {
        bestValue = -22120212;
    }
    
    if (this->turn == turn)
    {
        for (Move move : gameTree)
        {
            bestValue = min(bestValue, AlphaBetaPruning(gBoard, other(turn), depth - 1, move, Min, Max));
            if (Min >= min(Max, bestValue))
                break;
        }
    }
    else
    {
        for (Move move : gameTree)
        {
            bestValue = max(bestValue, AlphaBetaPruning(gBoard, other(turn), depth - 1, move, Min, Max));
            if (Max <= max(bestValue, Min))
                break;
        }
    }
    return bestValue;
}

// The following lines are _very_ important to create a bot module for Desdemona
extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
