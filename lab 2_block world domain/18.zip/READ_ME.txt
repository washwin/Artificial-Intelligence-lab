INSTRUCTIONS

To give manual input through terminal uncomment line number177
To change heuristic functions change heuristic1 to heuristic2 on line number 160, 161, 168
