Use python3 to execute the code
In the terminal enter the following command line
 py.exe .\18.py .\euc_100  
 py.exe .\18.py .\noneuc_100

for euclidean and non eulidean distances respectively 